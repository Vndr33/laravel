<div class="card">
    <form action="{{ url('logout') }}" method="POST"> @csrf 
        <button style="display: block; margin-left: auto; margin-right: 5%;" type="submit"> Logout </button>
    </form>
    <h1 style="color:#6CD66C;font-family:verdana;text-align:center">Dashboard</h1>
</div>